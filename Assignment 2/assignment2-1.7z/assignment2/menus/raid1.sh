clear
echo "RAID 1"
sleep 2
echo "HDD Permaters Loaded: $1"
sleep 1
echo "Sim Job Peramters Loaded: $2"
sleep 1
echo "Performing Operations..."
sleep 4
echo "Returning to Main Menu"
sleep 2
