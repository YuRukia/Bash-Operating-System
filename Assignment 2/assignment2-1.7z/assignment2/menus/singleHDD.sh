clear
echo "Single HDD"
sleep 2
echo "HDD Permaters Loaded: $(sed -n '1p' < $1)"
sleep 1
echo "Performing Operations..."

HDDs=$(echo $(sed -n '1p' < $1) | cut -d ':' -f1)
seekSpeed=$(echo $(sed -n '1p' < $1) | cut -d ':' -f2)
rwSpeed=$(echo $(sed -n '1p' < $1) | cut -d ':' -f3)

tasks=()
seek=()
rw=()

while IFS= read -r line
do
        tasks+=($line)
done < $2

for value in "${tasks[@]}"
do
        echo $value
done

for (( i=0; i<=${#tasks[@]}; i++ ))
do
        seek+=($seekSpeed)
        rw+=($rwSpeed)
done


for (( i=0; i<${#tasks[@]}; i++))
do
        echo "${tasks[$i]}:${seek[$i]}:${rw[$i]}"
done

read pause

echo "Returning to Main Menu"
sleep 2
