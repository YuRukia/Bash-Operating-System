#! /bin/bash

array=()

array+=(1)
array+=(5)

for value in "${array[@]}"
do
        echo "$value"
done
