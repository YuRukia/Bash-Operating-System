#! /bin/bash

string="R11"
str=$(echo $string | cut -c 2-)
echo $str
