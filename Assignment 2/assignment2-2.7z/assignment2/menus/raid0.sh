#!/bin/bash

clear
echo "RAID 0"
sleep 2
echo "HDD Permaters Loaded: $(sed -n '2p' < $1)"
sleep 1
echo "Performing Operations..."

HDDs=$(echo $(sed -n '2p' < $1) | cut -d ':' -f1)
seekSpeed=$(echo $(sed -n '2p' < $1) | cut -d ':' -f2)
rwSpeed=$(echo $(sed -n '2p' < $1)  | cut -d ':' -f3)

tasks=()
seek=()
rw=()

while IFS= read -r line
do
        tasks+=($line)
done < $2

for value in "${tasks[@]}"
do
        echo $value
done

#Last Job/Current Job
ljb=""
cjb=""
PARA=0

for (( i=0; i<=${#tasks[@]}; i++ ))
do
        cjb=$(echo ${tasks[$i]} | head -c 1)

        if [[ $cjb == $ljb ]]
        then
                if (( $PARA < $HDDs-1 ))
                then
                        PARA=$(($PARA+1))
                        seek+=("PARA")
                        rw+=(0)
                else    
                        seek+=($seekSpeed)
                        rw+=($rwSpeed)
                        PARA=0
                fi
        else
                PARA=0
                seek+=($seekSpeed)
                rw+=($rwSpeed)
        fi

        ljb=$(echo ${tasks[$i]} | head -c 1)
done

for (( i=0; i<${#tasks[@]}; i++))
do
        echo "${tasks[$i]}:${seek[$i]}:${rw[$i]}"
done

read pause

echo "Returning to Main Menu"
sleep 2
