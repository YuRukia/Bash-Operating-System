#! /bin/bash

clear
echo "Single HDD"
sleep 2
echo "HDD Permaters Loaded: $(sed -n '1p' < $1)"
sleep 1
echo "Performing Operations..."

HDDs=$(echo $(sed -n '1p' < $1) | cut -d ':' -f1)
seekSpeed=$(echo $(sed -n '1p' < $1) | cut -d ':' -f2)
rwSpeed=$(echo $(sed -n '1p' < $1) | cut -d ':' -f3)

tasks=()
seek=()
rw=()

while IFS= read -r line
do
        tasks+=($line)
done < $2

for value in "${tasks[@]}"
do
        echo $value
done

#Last Job(Number)/Current Job(Number)
ljb=""
ljbn=""
cjb=""
cjbn=""

for (( i=0; i<=${#tasks[@]}; i++ ))
do
        cjb=$(echo ${tasks[$i]} | head -c 1)
        cjbn=$(echo ${tasks[$i]} | cut -c 2-)

        if [[ $cjb == $ljb ]]
        then
                if [[ $cjbn == $ljbn ]]
                then
                        seek+=(0)
                        rw+=($rwSpeed)
                else
                        seek+=($seekSpeed)
                        rw+=($rwSpeed)
                fi
        else
                seek+=($seekSpeed)
                rw+=($rwSpeed)
        fi

        ljb=$(echo ${tasks[$i]} | head -c 1)
        ljbn=$(echo ${tasks[$i]} | cut -c 2-)
        ljbn=$(($ljbn+1))
done

for (( i=0; i<${#tasks[@]}; i++))
do
        echo "${tasks[$i]}:${seek[$i]}:${rw[$i]}"
done

read pause

echo "Returning to Main Menu"
sleep 2
