#!/bin/bash

source ./funcs.sh

clear
echo "RAID 1"
sleep 2
echo "HDD Permaters Loaded: $(sed -n '4p' < $1)"
sleep 1
echo "Performing Operations..."

HDDs=$(echo $(sed -n '4p' < $1) | cut -d ':' -f1)
seekSpeed=$(echo $(sed -n '4p' < $1) | cut -d ':' -f2)
rwSpeed=$(echo $(sed -n '4p' < $1)  | cut -d ':' -f3)

tasks=()
seek=()
rw=()

while IFS= read -r line
do
        tasks+=($line)
done < $2

for value in "${tasks[@]}"
do
        echo $value
done

#Last Job(Number)/Current Job(Number)
ljb=""
ljbn=""
cjb=""
cjbn=""
PARA=0

for (( i=0; i<=${#tasks[@]}; i++ ))
do
        cjb=$(echo ${tasks[$i]} | head -c 1)
        cjbn=$(echo ${tasks[$i]} | cut -c 2-) 

        if [[ $cjb == "R" ]] && (( $PARA < $HDDs ))
        then
                if (( $PARA > 0 ))
                then
                        PARA=$(($PARA+1))
                        seek+=("PARA")
                        rw+=(0)
                else
                        PARA=$(($PARA+1))
                        seek+=($seekSpeed)
                        rw+=($rwSpeed)
                fi
        else
                PARA=0
                if [[ $cjbn == $ljbn ]]
                then
                        seek+=(0)
                        rw+=(60)
                else
                        seek+=($seekSpeed)
                        rw+=($rwSpeed)
                fi
        fi
        ljb=$(echo ${tasks[$i]} | head -c 1)
        ljbn=$(echo ${tasks[$i]} | cut -c 2-)
        ljbn=$(($ljbn+1))
done

for (( i=0; i<${#tasks[@]}; i++))
do
        echo "${tasks[$i]}:${seek[$i]}:${rw[$i]}"
done

read pause

echo "Returning to Main Menu"
sleep 2
